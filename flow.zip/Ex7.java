import java.util.*;
public class Ex7 {
	public static void main(String[] args)
 {
	Scanner sc=new Scanner(System.in);
	String s=sc.next();
	String s1=s.toLowerCase();
	if(s.equals(s1))
	{
		System.out.println(s1.toUpperCase());
	}
	else
	{
		System.out.println(s1.toLowerCase());
	}
	}
}