import java.util.*;
public class Ex17{

    public static void main(String[] args) {
       Scanner sc=new Scanner(System.in);
        int num = sc.nextInt();
         int revint= 0; 
        int remainder;
        int orgint;

        orgint = num;

        while( num != 0 )
        {
            remainder = num % 10;
            revint = revint* 10 + remainder;
            num  /= 10;
        }

   
        if (orgint == revint)
            System.out.println(orgint + " is a palindrome.");
        else
            System.out.println(orgint + " is not a palindrome.");
    }
}