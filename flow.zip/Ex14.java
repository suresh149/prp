import java.util.Scanner;

public class Ex14 {

	public static void main(String[] args) {
		   Scanner sc=new Scanner(System.in);
		   System.out.println("Enter a number ");
		 long n=sc.nextLong();
		 long sum;
  	 

        
for(sum=0 ;n!=0 ;n/=10)
{
sum+=n%10;
}
System.out.println("Sum of digits of a number is "+sum);          

	}

}
